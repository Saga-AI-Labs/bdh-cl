#!/usr/bin/env bash
# Position decomposition of the early-window margin for the two code crops whose
# misroute was against a peer route (not the base): idx 45 -> 53248, idx 71 -> 57344.
set -uo pipefail
cd /srv/coding/bdh-cl || exit 1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
PY=.venv/bin/python
LOG=out_a/logs/code_posdump.log
: > "$LOG"
for PEER in 53248 57344; do
  echo "===== POS_DUMP code: own 49152 vs peer $PEER $(date '+%F %T') =====" >> "$LOG"
  /usr/bin/time -f "WALL=%es MAXRSS=%MkB" timeout 3600 $PY -u scripts/eval_router.py \
    out_a/bdh_textmix_k25w1024-zh_last.pt \
    --routes "49152,$PEER" \
    --domains "code:data/textmix2/code.txt" \
    --mb 30 --window 128 --crops 200 --batch 4 \
    --pos-dump "code:49152,$PEER" >> "$LOG" 2>&1
  echo "POSDUMP peer=$PEER rc=$? at $(date '+%F %T')" >> "$LOG"
done
echo "===== ALL POS DUMPS DONE $(date '+%F %T') =====" >> "$LOG"
