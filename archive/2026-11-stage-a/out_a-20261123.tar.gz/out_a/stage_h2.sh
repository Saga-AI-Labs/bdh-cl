#!/usr/bin/env bash
# Stage H2 (RBC-1): same crops, same checkpoint, scoring window 384 instead of 128.
# Block size 512, so 384 keeps a 128-token late span -- the leg-5 substitution.
# One domain per call so manual_seed(1234) yields the same crop indices as the
# window-128 runs, making the pairing exact.
set -uo pipefail
cd /srv/coding/bdh-cl || exit 1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
PY=.venv/bin/python
ROUTES=$(python3 -c "print(','.join(str((128+32*k)*64) for k in range(0,25)))")
for SPEC in "legal:data/textmix2/legal.txt" "code:data/textmix2/code.txt"; do
  TAG=${SPEC%%:*}
  LOG=out_a/logs/scores384_${TAG}.log
  if grep -q "^SCORES_DONE" "$LOG" 2>/dev/null; then
    echo "SKIP $TAG (complete)" >> out_a/logs/stage_h2_runner.log
    continue
  fi
  echo "===== SCORES384 $TAG $(date '+%F %T') =====" >> "$LOG"
  /usr/bin/time -f "WALL=%es MAXRSS=%MkB" timeout 14400 $PY -u scripts/eval_router.py \
    out_a/bdh_textmix_k25w1024-zh_last.pt --routes "$ROUTES" --domains "$SPEC" \
    --mb 30 --window 384 --crops 200 --batch 4 --score-vector >> "$LOG" 2>&1
  RC=$?
  echo "SCORES_DONE $TAG rc=$RC $(date '+%F %T')" >> "$LOG"
  if [ "$RC" -ne 0 ]; then echo "ABORT $TAG rc=$RC" >> out_a/logs/stage_h2_runner.log; fi
done
echo "===== STAGE H2 DONE $(date '+%F %T') =====" >> out_a/logs/stage_h2_runner.log
