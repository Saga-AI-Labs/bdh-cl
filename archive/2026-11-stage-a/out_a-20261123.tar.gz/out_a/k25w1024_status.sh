#!/usr/bin/env bash
cd /srv/coding/bdh-cl || exit 1
LOG=out_a/logs/k25w1024-base.log
echo "== $(date '+%F %T') =="
P=$(pgrep -f "run-name k25w1024-base" | head -1)
if [ -n "$P" ]; then
  ps -o etimes=,pcpu=,rss= -p "$P" | awk '{printf "RUNNING pid=%s up=%ss cpu=%s%% rss=%.0fMB\n", "'"'"'$P'"'"'", $1,$2,$3/1024}'
else
  echo "NOT RUNNING. last log lines:"; tail -5 "$LOG"
fi
echo "-- gpu --"
nvidia-smi --query-gpu=utilization.gpu,power.draw --format=csv,noheader | head -1
echo "-- last log lines --"
tail -4 "$LOG" 2>/dev/null || echo '(log empty)'
echo "-- checkpoints --"
ls -lh out_a/*.pt 2>/dev/null | tail -2 || echo 'none yet'
