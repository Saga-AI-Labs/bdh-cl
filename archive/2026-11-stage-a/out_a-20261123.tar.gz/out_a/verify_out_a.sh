#!/bin/bash
set -u
TOKEN=$(cat /srv/coding/bdh-cl/out_c/hf_token)
LOCAL=/srv/coding/bdh-cl/out_a
REPO=Saga-AI-Labs/bdh-k25w1024-ladder
TMP=/tmp/verify_out_a
mkdir -p "$TMP"
LOG=/srv/coding/bdh-cl/out_a/verify_out_a.log
: > "$LOG"
for F in bdh_textmix_k25w1024-legal_last.pt bdh_textmix_k25w1024-zh_best.pt bdh_textmix_k25w1024-zh_last.pt; do
  echo "=== $F ===" | tee -a "$LOG"
  if [ ! -f "$LOCAL/$F" ]; then echo "  MISSING local $F" | tee -a "$LOG"; continue; fi
  LS=$(sha256sum "$LOCAL/$F" | awk '{print $1}')
  LZ=$(stat -c %s "$LOCAL/$F")
  echo "  local  size $LZ" | tee -a "$LOG"
  echo "  local  sha256 $LS" | tee -a "$LOG"
  curl -sL -H "Authorization: Bearer $TOKEN" \
    "https://huggingface.co/datasets/$REPO/resolve/main/$F" -o "$TMP/$F"
  RZ=$(stat -c %s "$TMP/$F")
  RS=$(sha256sum "$TMP/$F" | awk '{print $1}')
  echo "  remote size $RZ" | tee -a "$LOG"
  echo "  remote sha256 $RS" | tee -a "$LOG"
  if [ "$LS" = "$RS" ] && [ "$LZ" = "$RZ" ]; then echo "  OK $F" | tee -a "$LOG"; else echo "  MISMATCH $F" | tee -a "$LOG"; fi
  rm -f "$TMP/$F"
done
echo "### verify_out_a done $(date -Is) ###" | tee -a "$LOG"
