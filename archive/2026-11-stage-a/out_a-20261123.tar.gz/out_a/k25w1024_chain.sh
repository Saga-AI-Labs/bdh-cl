#!/usr/bin/env bash
# K25/W1024 Bridge — 24 grow phases, sequential, detached.
# Resumable at phase boundaries: a phase whose _last.pt exists is skipped.
set -uo pipefail
cd /srv/coding/bdh-cl || exit 1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
PY=.venv/bin/python
OUT=out_a
LOG=out_a/logs
MAIN=$LOG/k25w1024_chain.log
mkdir -p "$LOG" "$OUT"

log(){ echo "$*" | tee -a "$MAIN"; }

log "=== K25W1024 CHAIN START $(date '+%F %T') ==="

INIT="$OUT/bdh_textmix_k25w1024-base_last.pt"
if [ ! -f "$INIT" ]; then log "FATAL: base checkpoint missing: $INIT"; exit 2; fi
log "base=$INIT bytes=$(stat -c %s "$INIT")"

# tag:corpus  (order and paths verbatim from K20 prereg table)
PHASES=(
  "es:data/europarl/europarl-v7.es-en.es.txt"
  "pl:data/europarl/europarl-v7.pl-en.pl.txt"
  "fr:data/europarl/europarl-v7.fr-en.fr.txt"
  "de:data/europarl/europarl-v7.de-en.de.txt"
  "cs:data/europarl/europarl-v7.cs-en.cs.txt"
  "da:data/europarl/europarl-v7.da-en.da.txt"
  "pt:data/europarl/europarl-v7.pt-en.pt.txt"
  "fi:data/europarl/europarl-v7.fi-en.fi.txt"
  "hu:data/europarl/europarl-v7.hu-en.hu.txt"
  "bg:data/europarl/europarl-v7.bg-en.bg.txt"
  "it:data/europarl/europarl-v7.it-en.it.txt"
  "et:data/europarl/europarl-v7.et-en.et.txt"
  "el:data/europarl/europarl-v7.el-en.el.txt"
  "sk:data/europarl/europarl-v7.sk-en.sk.txt"
  "sv:data/europarl/europarl-v7.sv-en.sv.txt"
  "ro:data/europarl/europarl-v7.ro-en.ro.txt"
  "nl:data/europarl/europarl-v7.nl-en.nl.txt"
  "sl:data/europarl/europarl-v7.sl-en.sl.txt"
  "lt:data/europarl/europarl-v7.lt-en.lt.txt"
  "code:data/textmix2/code.txt"
  "math:data/textmix2/latex.txt"
  "legal:data/textmix2/legal.txt"
  "ga:data/europarl/DGT.en-ga.ga.txt"
  "zh:data/europarl/xscript_zh.txt"
)

N=0
for spec_pair in "${PHASES[@]}"; do
  N=$((N+1))
  TAG="${spec_pair%%:*}"
  CORPUS="${spec_pair#*:}"
  EXPECT="$OUT/bdh_textmix_k25w1024-${TAG}_last.pt"
  PHLOG="$LOG/k25w1024-${TAG}.log"

  if [ -f "$EXPECT" ]; then
    log "SKIP phase $N/24 $TAG (checkpoint exists, $(stat -c %s "$EXPECT") bytes)"
    INIT="$EXPECT"
    continue
  fi
  if [ ! -f "$CORPUS" ]; then log "FATAL phase $N $TAG: corpus missing $CORPUS"; exit 3; fi

  FREE=$(df -B1 --output=avail / | tail -1)
  if [ "$FREE" -lt 300000000000 ]; then log "ABORT before phase $N $TAG: free=${FREE}B < 300GB"; exit 4; fi

  log "START phase $N/24 $TAG $(date '+%F %T') init=$INIT free=${FREE}B"
  T0=$(date +%s)
  timeout 24h $PY -u -m pipeline.run train \
    --model bdh --dataset textmix \
    --text-mix "$TAG:$CORPUS" --text-mix-mb 30 \
    --n-embd 1024 --n-head 16 --block-size 512 \
    --max-iters 10000 --batch-size 1 \
    --warmup-iters 1000 --lr-decay-iters 10000 \
    --grow-mult 32 --init-from "$INIT" \
    --no-freeze-attn --route-aware --route-alpha 0.9 \
    --compile \
    --out-dir "$OUT" --run-name "k25w1024-$TAG" >> "$PHLOG" 2>&1
  RC=$?
  T1=$(date +%s)

  if [ ! -f "$EXPECT" ]; then
    log "FAIL phase $N/24 $TAG rc=$RC wall=$((T1-T0))s — no checkpoint; chain stops"
    exit 5
  fi
  log "DONE phase $N/24 $TAG rc=$RC wall=$((T1-T0))s bytes=$(stat -c %s "$EXPECT")"
  INIT="$EXPECT"
done

log "=== K25W1024 CHAIN COMPLETE $(date '+%F %T') ==="
