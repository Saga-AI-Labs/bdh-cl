#!/usr/bin/env bash
set -uo pipefail
cd /srv/coding/bdh-cl || exit 1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
PY=.venv/bin/python
ROUTES=$(python3 -c "print(','.join(str((128+32*k)*64) for k in range(0,25)))")
for SPEC in "legal:data/textmix2/legal.txt" "code:data/textmix2/code.txt"; do
  TAG=${SPEC%%:*}
  LOG=out_a/logs/scores_${TAG}.log
  echo "===== SCORES $TAG $(date '+%F %T') =====" >> "$LOG"
  /usr/bin/time -f "WALL=%es MAXRSS=%MkB" timeout 14400 $PY -u scripts/eval_router.py \
    out_a/bdh_textmix_k25w1024-zh_last.pt --routes "$ROUTES" --domains "$SPEC" \
    --mb 30 --window 128 --crops 200 --batch 4 --score-vector >> "$LOG" 2>&1
  echo "SCORES_DONE $TAG rc=$? $(date '+%F %T')" >> "$LOG"
done
echo "===== STAGE B DONE $(date '+%F %T') =====" >> out_a/logs/stage_b_runner.log
