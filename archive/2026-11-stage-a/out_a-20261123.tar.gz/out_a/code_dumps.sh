#!/usr/bin/env bash
# Two missing margin dumps for code: own width 49152 against the two peers that
# also captured misroutes at n=200 (53248 and 57344).
set -uo pipefail
cd /srv/coding/bdh-cl || exit 1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
PY=.venv/bin/python
LOG=out_a/logs/code_margin200.log
for PEER in 53248 57344; do
  {
    echo ""
    echo "===== DUMP code: own 49152 vs peer $PEER $(date '+%F %T') ====="
  } >> "$LOG"
  /usr/bin/time -f "WALL=%es MAXRSS=%MkB" timeout 3600 $PY -u scripts/eval_router.py \
    out_a/bdh_textmix_k25w1024-zh_last.pt \
    --routes "49152,$PEER" \
    --domains "code:data/textmix2/code.txt" \
    --mb 30 --window 128 --crops 200 --batch 4 \
    --crop-dump "code:49152,$PEER" >> "$LOG" 2>&1
  RC=$?
  echo "DUMP peer=$PEER rc=$RC at $(date '+%F %T')" >> "$LOG"
done
echo "===== ALL CODE DUMPS DONE $(date '+%F %T') =====" >> "$LOG"
