#!/usr/bin/env bash
# Position decomposition for legal: own width 53248 vs the base route 8192.
# All 19 of the 200 legal misroutes went to 8192, so this single pair covers them.
set -uo pipefail
cd /srv/coding/bdh-cl || exit 1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
LOG=out_a/logs/legal_posdump.log
: > "$LOG"
echo "===== POS_DUMP legal: own 53248 vs base 8192 $(date '+%F %T') =====" >> "$LOG"
/usr/bin/time -f "WALL=%es MAXRSS=%MkB" timeout 3600 .venv/bin/python -u scripts/eval_router.py \
  out_a/bdh_textmix_k25w1024-zh_last.pt \
  --routes "53248,8192" \
  --domains "legal:data/textmix2/legal.txt" \
  --mb 30 --window 128 --crops 200 --batch 4 \
  --pos-dump "legal:53248,8192" >> "$LOG" 2>&1
RC=$?
echo "POSDUMP legal rc=$RC at $(date '+%F %T')" >> "$LOG"
echo "===== LEGAL POS DUMP DONE $(date '+%F %T') =====" >> "$LOG"
