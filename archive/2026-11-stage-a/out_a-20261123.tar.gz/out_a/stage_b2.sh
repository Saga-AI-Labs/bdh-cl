#!/usr/bin/env bash
# Stage (b2): score vectors for three further domains, to test whether the base
# route 8192 is systematically competitive off-domain or only on legal/code.
set -uo pipefail
cd /srv/coding/bdh-cl || exit 1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
PY=.venv/bin/python
ROUTES=$(python3 -c "print(','.join(str((128+32*k)*64) for k in range(0,25)))")
for SPEC in "math:data/textmix2/latex.txt" "zh:data/europarl/xscript_zh.txt" "ga:data/europarl/DGT.en-ga.ga.txt"; do
  TAG=${SPEC%%:*}
  LOG=out_a/logs/scores_${TAG}.log
  if grep -q "^SCORES_DONE" "$LOG" 2>/dev/null; then
    echo "SKIP $TAG (complete)" >> out_a/logs/stage_b2_runner.log
    continue
  fi
  echo "===== SCORES $TAG $(date '+%F %T') =====" >> "$LOG"
  /usr/bin/time -f "WALL=%es MAXRSS=%MkB" timeout 14400 $PY -u scripts/eval_router.py \
    out_a/bdh_textmix_k25w1024-zh_last.pt --routes "$ROUTES" --domains "$SPEC" \
    --mb 30 --window 128 --crops 200 --batch 4 --score-vector >> "$LOG" 2>&1
  RC=$?
  echo "SCORES_DONE $TAG rc=$RC $(date '+%F %T')" >> "$LOG"
  if [ "$RC" -ne 0 ]; then echo "ABORT: $TAG rc=$RC" >> out_a/logs/stage_b2_runner.log; fi
done
echo "===== STAGE B2 DONE $(date '+%F %T') =====" >> out_a/logs/stage_b2_runner.log
