#!/usr/bin/env bash
# H2 control group: domains that were PERFECT at window 128 (math, zh).
# If the window-384 improvement is a mechanism, these stay clean. If it is an
# artefact fitted to legal/code, they can only lose cases. One domain per call
# so manual_seed(1234) reproduces the same crop indices as the window-128 runs.
set -uo pipefail
cd /srv/coding/bdh-cl || exit 1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
PY=.venv/bin/python
ROUTES=$(python3 -c "print(','.join(str((128+32*k)*64) for k in range(0,25)))")
for SPEC in "zh:data/europarl/xscript_zh.txt" "math:data/textmix2/latex.txt"; do
  TAG=${SPEC%%:*}
  LOG=out_a/logs/scores384_${TAG}.log
  if grep -q "^SCORES_DONE" "$LOG" 2>/dev/null; then
    echo "SKIP $TAG (complete)" >> out_a/logs/stage_h2_control_runner.log
    continue
  fi
  echo "===== SCORES384 $TAG $(date '+%F %T') =====" >> "$LOG"
  /usr/bin/time -f "WALL=%es MAXRSS=%MkB" timeout 14400 $PY -u scripts/eval_router.py \
    out_a/bdh_textmix_k25w1024-zh_last.pt --routes "$ROUTES" --domains "$SPEC" \
    --mb 30 --window 384 --crops 200 --batch 4 --score-vector >> "$LOG" 2>&1
  RC=$?
  echo "SCORES_DONE $TAG rc=$RC $(date '+%F %T')" >> "$LOG"
  if [ "$RC" -ne 0 ]; then echo "ABORT $TAG rc=$RC" >> out_a/logs/stage_h2_control_runner.log; fi
done
echo "===== H2 CONTROL DONE $(date '+%F %T') =====" >> out_a/logs/stage_h2_control_runner.log
