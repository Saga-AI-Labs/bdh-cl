#!/usr/bin/env bash
# Per-domain n=100 routing sweep. One domain per evaluator call so the shared
# crop generator (manual_seed 1234) yields a reproducible sample per domain.
set -uo pipefail
cd /srv/coding/bdh-cl || exit 1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
PY=.venv/bin/python
OUTLOG=out_a/logs/sweep_n100.log
ROUTES=$(python3 -c "print(','.join(str((128+32*k)*64) for k in range(0,25)))")
mkdir -p out_a/logs/sweep_n100
log(){ echo "$*" | tee -a "$OUTLOG"; }

DOMAINS=(
  "prose:data/textmix/wikitext-103-raw/wiki.train.raw"
  "es:data/europarl/europarl-v7.es-en.es.txt"
  "pl:data/europarl/europarl-v7.pl-en.pl.txt"
  "fr:data/europarl/europarl-v7.fr-en.fr.txt"
  "de:data/europarl/europarl-v7.de-en.de.txt"
  "cs:data/europarl/europarl-v7.cs-en.cs.txt"
  "da:data/europarl/europarl-v7.da-en.da.txt"
  "pt:data/europarl/europarl-v7.pt-en.pt.txt"
  "fi:data/europarl/europarl-v7.fi-en.fi.txt"
  "hu:data/europarl/europarl-v7.hu-en.hu.txt"
  "bg:data/europarl/europarl-v7.bg-en.bg.txt"
  "it:data/europarl/europarl-v7.it-en.it.txt"
  "et:data/europarl/europarl-v7.et-en.et.txt"
  "el:data/europarl/europarl-v7.el-en.el.txt"
  "sk:data/europarl/europarl-v7.sk-en.sk.txt"
  "sv:data/europarl/europarl-v7.sv-en.sv.txt"
  "ro:data/europarl/europarl-v7.ro-en.ro.txt"
  "nl:data/europarl/europarl-v7.nl-en.nl.txt"
  "sl:data/europarl/europarl-v7.sl-en.sl.txt"
  "lt:data/europarl/europarl-v7.lt-en.lt.txt"
  "code:data/textmix2/code.txt"
  "math:data/textmix2/latex.txt"
  "ga:data/europarl/DGT.en-ga.ga.txt"
  "zh:data/europarl/xscript_zh.txt"
)

log "=== SWEEP n=100 START $(date '+%F %T') | ${#DOMAINS[@]} domains | 25 routes ==="
N=0
for spec in "${DOMAINS[@]}"; do
  N=$((N+1))
  TAG="${spec%%:*}"
  LOG=out_a/logs/sweep_n100/${TAG}.log
  if grep -q "^WALL=" "$LOG" 2>/dev/null; then
    log "SKIP $N ${#DOMAINS[@]} $TAG (already complete)"
    continue
  fi
  log "START $N/${#DOMAINS[@]} $TAG $(date '+%F %T')"
  /usr/bin/time -f "WALL=%es MAXRSS=%MkB" timeout 7200 $PY -u scripts/eval_router.py \
    out_a/bdh_textmix_k25w1024-zh_last.pt \
    --routes "$ROUTES" \
    --domains "$spec" \
    --mb 30 --window 128 --crops 100 --batch 4 --route-grid \
    > "$LOG" 2>&1
  RC=$?
  if grep -q "^WALL=" "$LOG"; then
    ACC=$(grep -A2 'confusion' "$LOG" | tail -1 | awk -v t="$TAG" '$1==t{for(i=2;i<=NF;i++) if($i>0) {split($0,a," "); print}}' | head -1)
    log "DONE $N/${#DOMAINS[@]} $TAG rc=$RC $(grep '^WALL=' "$LOG")"
  else
    log "FAIL $N/${#DOMAINS[@]} $TAG rc=$RC -- no WALL line; sweep stops"
    exit 5
  fi
done
log "=== SWEEP n=100 COMPLETE $(date '+%F %T') ==="
