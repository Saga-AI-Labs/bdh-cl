#!/usr/bin/env bash
# H2 third point: window 256 at block 512. Same crops, same checkpoint.
# legal and code only -- the domains that still have misroutes at 384.
set -uo pipefail
cd /srv/coding/bdh-cl || exit 1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
PY=.venv/bin/python
ROUTES=$(python3 -c "print(','.join(str((128+32*k)*64) for k in range(0,25)))")
for SPEC in "legal:data/textmix2/legal.txt" "code:data/textmix2/code.txt"; do
  TAG=${SPEC%%:*}
  LOG=out_a/logs/scores256_${TAG}.log
  echo "===== SCORES256 $TAG $(date '+%F %T') =====" >> "$LOG"
  /usr/bin/time -f "WALL=%es MAXRSS=%MkB" timeout 14400 $PY -u scripts/eval_router.py \
    out_a/bdh_textmix_k25w1024-zh_last.pt --routes "$ROUTES" --domains "$SPEC" \
    --mb 30 --window 256 --crops 200 --batch 4 --score-vector >> "$LOG" 2>&1
  RC=$?
  echo "SCORES_DONE $TAG rc=$RC $(date '+%F %T')" >> "$LOG"
  if [ "$RC" -ne 0 ]; then echo "ABORT $TAG rc=$RC" >> out_a/logs/stage_w256_runner.log; fi
done
echo "===== W256 DONE $(date '+%F %T') =====" >> out_a/logs/stage_w256_runner.log
