#!/usr/bin/env python3
"""Delete the K25/W1024 ladder checkpoints that are verified on HuggingFace.

Safety model: nothing is deleted unless its SHA256 appears as OK in
out_c/expert_merge/checksum_verify.json. A file that was not verified is kept and
reported. The keep list is explicit; everything else in the ladder directories is
a candidate.

Keep list (operator, 2026-11-08):
  out_c/expert_merge/zh_b1_merged.pt        (serving checkpoint, 22 GB)
  out_c/expert_merge/bdh_textmix_expert-b1_last.pt   (32 GB)
  out_c/expert_merge/bdh_textmix_expert-b1_best.pt   (32 GB)
  out_a/bdh_textmix_k25w1024-zh_last.pt    (34 GB)
  out_a/bdh_textmix_k25w1024-zh_best.pt    (34 GB)
  out_a/bdh_textmix_k25w1024-legal_last.pt (31 GB)

Delete candidates: every other .pt under out_a/ (the 24 phase checkpoints).

Usage:
    python cleanup_ladder.py --dry-run     # list what would go, delete nothing
    python cleanup_ladder.py               # delete verified files
"""
import argparse
import json
import os
import sys

VERIFY = "/srv/coding/bdh-cl/out_c/expert_merge/checksum_verify.json"
BASE = "/srv/coding/bdh-cl"

KEEP = {
    "out_c/expert_merge/zh_b1_merged.pt",
    "out_c/expert_merge/bdh_textmix_expert-b1_last.pt",
    "out_c/expert_merge/bdh_textmix_expert-b1_best.pt",
    "out_a/bdh_textmix_k25w1024-zh_last.pt",
    "out_a/bdh_textmix_k25w1024-zh_best.pt",
    "out_a/bdh_textmix_k25w1024-legal_last.pt",
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    v = json.load(open(VERIFY))
    # the verify JSON records bare filenames (staging dir); candidates carry a
    # relative path, so match on the basename.
    ok_files = {os.path.basename(r["file"]) for r in v["results"] if r["status"] == "OK"}
    print("verified OK: %d files" % len(ok_files))
    print("summary: %s" % json.dumps(v["summary"]))

    # candidates: every .pt under out_a/
    candidates = []
    for root, dirs, files in os.walk(os.path.join(BASE, "out_a")):
        for f in files:
            if f.endswith(".pt"):
                candidates.append(os.path.relpath(os.path.join(root, f), BASE))
    candidates.sort()

    to_delete, keep_unverified = [], []
    for c in candidates:
        if c in KEEP:
            continue
        if os.path.basename(c) in ok_files:
            to_delete.append(c)
        else:
            keep_unverified.append(c)

    total = sum(os.path.getsize(os.path.join(BASE, f)) for f in to_delete)
    print()
    print("keep list: %d files" % len(KEEP))
    print("candidates under out_a/: %d" % len(candidates))
    print("to delete: %d files, %.2f GB" % (len(to_delete), total / 1e9))
    print("kept because unverified: %d" % len(keep_unverified))
    for f in keep_unverified:
        print("  KEEP-UNVERIFIED %s" % f)
    print()
    for f in to_delete:
        print("  DELETE %s" % f)

    if args.dry_run:
        print("\nDRY RUN -- nothing deleted")
        return 0

    print()
    deleted = 0
    failed = 0
    for f in to_delete:
        p = os.path.join(BASE, f)
        try:
            os.remove(p)
            deleted += 1
            print("  removed %s" % f)
        except Exception as e:
            failed += 1
            print("  FAILED %s: %s" % (f, e))

    print("\ndeleted: %d | failed: %d" % (deleted, failed))
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
