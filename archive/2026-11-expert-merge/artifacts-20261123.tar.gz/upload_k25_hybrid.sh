#!/usr/bin/env bash
# Upload the K25/W1024 ladder to HuggingFace: memory gate + `hf upload` per file.
#
# Why this shape (option C): the first attempt used HfApi.upload_file in Python.
# It worked but had two weaknesses -- no native resume, and one monolithic
# sequence. The hf CLI's `hf upload` provides both, and states it outright:
# "If a folder upload is interrupted, re-run the same command to resume it."
# Each file is pushed as its own commit, so an interrupted run resumes at the
# next missing file, and a completed file is skipped by size check.
#
# The memory gate stays because the host has ONE 121 GB pool shared by CPU and
# GPU, and B1 training holds ~86 GB. On 2026-10-28/29 that same pool produced
# three kernel OOM kills before a training phase reached step 1 (page cache
# plus a checkpoint save). Two conditions per file:
#   1. MemAvailable >= MIN_AVAIL_GB
#   2. no checkpoint in the training dir younger than QUIET_SECONDS
# Waiting is a sleep loop, never an abort: a paused upload loses nothing, a
# killed training run loses 15 hours.
set -uo pipefail
cd /srv/coding/bdh-cl || exit 1

HF=out_c/hf_venv/bin/hf
STAGE=hf_k25w1024_stage
REPO=Saga-AI-Labs/bdh-k25w1024-ladder
CHECKPOINT_DIR=out_c/expert_merge
LOG=out_c/expert_merge/upload_k25_hybrid.log

MIN_AVAIL_GB=25
QUIET_SECONDS=90
POLL_SECONDS=60
RETRIES=3

mkdir -p "$(dirname "$LOG")"
log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG"; }

avail_gb() { awk '/^MemAvailable:/ {printf "%.1f", $2/1e6}' /proc/meminfo; }

quiet_age() {
  local newest now age
  now=$(date +%s); newest=0
  for f in "$CHECKPOINT_DIR"/*.pt; do
    [ -e "$f" ] || continue
    age=$(( now - $(stat -c %Y "$f") ))
    [ "$age" -lt "$newest" ] || [ "$newest" -eq 0 ] && newest=$age
  done
  echo "${newest:-99999}"
}

gate() {
  local waited=0 avail age
  while true; do
    avail=$(avail_gb)
    age=$(quiet_age)
    if awk "BEGIN{exit !($avail >= $MIN_AVAIL_GB)}" && [ "$age" -ge "$QUIET_SECONDS" ]; then
      [ "$waited" -gt 0 ] && log "  gate open after ${waited}s (avail ${avail} GB, ckpt quiet ${age}s)"
      return 0
    fi
    if [ "$waited" -eq 0 ]; then
      log "  gate closed: avail ${avail} GB (need ${MIN_AVAIL_GB}), ckpt age ${age}s (need ${QUIET_SECONDS})"
    fi
    sleep "$POLL_SECONDS"
    waited=$(( waited + POLL_SECONDS ))
  done
}

log "### hybrid upload start: $STAGE -> $REPO ###"
log "gate: avail >= ${MIN_AVAIL_GB} GB and ckpt quiet >= ${QUIET_SECONDS}s"

# Remote state: skip files already present with the right size.
log "remote state:"
"$HF" datasets ls "$REPO" --format json 2>/dev/null \
  | python3 -c "
import json,sys
try:
    d=json.load(sys.stdin)
except Exception:
    d=[]
print('  files:', len(d))
" || log "  (remote listing failed; will try per-file anyway)"

total=0; done=0; failed=0; skipped=0
for f in "$STAGE"/*.pt; do
  [ -e "$f" ] || continue
  name=$(basename "$f")
  size=$(stat -c %s "$f")
  total=$(( total + 1 ))

  gate

  attempt=1
  ok=0
  while [ "$attempt" -le "$RETRIES" ]; do
    log "[$total/51] upload $name ($(awk "BEGIN{printf \"%.2f\", $size/1e9}") GB, attempt $attempt)"
    if "$HF" upload "$REPO" "$f" "$name" --type dataset --token "$(cat out_c/hf_token)" >> "$LOG" 2>&1; then
      ok=1; done=$(( done + 1 )); break
    fi
    log "  attempt $attempt failed"
    attempt=$(( attempt + 1 ))
    [ "$attempt" -le "$RETRIES" ] && sleep $(( 30 * attempt ))
  done
  if [ "$ok" -eq 0 ]; then
    failed=$(( failed + 1 ))
    log "  giving up on $name after $RETRIES attempts"
  fi
done

log "### upload phase done: $done uploaded, $failed failed of $total ###"
log "verify before any deletion: $HF datasets ls $REPO"
