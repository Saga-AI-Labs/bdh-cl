#!/usr/bin/env bash
# Learning-rate probe for the expert-merge branch (prereg 2.3).
#
# Why this exists: the frozen prereg says "identical schedule" for B1/B2 but never
# names a learning rate. The pipeline default is 1e-3 with warmup 30 / decay 300,
# which is a from-scratch schedule. The ladder used 1e-3 with warmup 1000 / decay
# 10000 over 10k steps. The branch has 41,130 steps per epoch at batch 1, so the
# ladder schedule does not transfer either. Guessing would risk 1.5 days of GPU.
#
# This probe runs 100 steps at each candidate rate on the REAL branch setup
# (zh_last, mult 896, the Gutenberg corpus, freeze-embed, weight-decay 0) and
# reports the loss trajectory. It does not train a branch; it answers one
# question: does this rate destroy the model or improve it?
#
# Decision rule, fixed BEFORE the numbers are seen:
#   PASS  loss at the last logged step <= loss at the first, and no step exceeds
#         2x the first loss (that would be collapse).
#   FAIL  otherwise.
# If more than one rate passes, the one with the lowest final loss wins, with a
# tie broken toward the lower rate (less destructive).
#
# --seed 1234 is fixed here for the same reason GLM proposes it for B1/B2:
# it determines the batch order (torch.randint in get_batch) and the
# dropout masks, so two arms see identical data sequences and differ only
# in the variable under test. Matched pairs, not bit-exactness -- CUDA
# reduction order is still free to vary.
set -uo pipefail
cd /srv/coding/bdh-cl || exit 1

PY=.venv/bin/python
PARENT=out_a/bdh_textmix_k25w1024-zh_last.pt
OUT=out_c/expert_merge/lr_probe
LOGS=out_c/expert_merge/lr_probe_logs
mkdir -p "$OUT" "$LOGS"

# text-mix-mb 30 against a 21 MB corpus means "read the whole file";
# _prepare_textmix then carves 2 MB off the tail for val/test, leaving ~19 MB train.
BASE="--model bdh --dataset textmix \
  --text-mix expert:data/expert/train.txt --text-mix-mb 30 \
  --n-embd 1024 --n-head 16 --mlp-internal-dim-multiplier 896 \
  --block-size 512 --batch-size 1 --max-iters 100 \
  --weight-decay 0 --seed 1234 --init-from $PARENT --freeze-embed --out-dir $OUT"

run_arm () {
  local tag="$1" lr="$2" warm="$3" decay="$4"
  local log="$LOGS/arm-$tag.log"
  echo ""
  echo "=============================================================="
  echo "ARM $tag : lr=$lr warmup=$warm decay=$decay"
  echo "=============================================================="
  $PY -u -m pipeline.run train $BASE \
    --learning-rate "$lr" --warmup-iters "$warm" --lr-decay-iters "$decay" \
    --run-name "lr-$tag" > "$log" 2>&1
  local rc=$?
  grep -E 'step [0-9]+ \||optimizer:|freeze-embed|model:' "$log" | tail -8
  echo "-> rc=$rc | log=$log | ckpt=$(ls "$OUT"/*lr-$tag*_last.pt 2>/dev/null | head -1)"
}

run_arm A 1e-4 20 100
run_arm B 3e-4 20 100
run_arm C 1e-3 10 100

echo ""
echo "=============================================================="
echo "SUMMARY"
echo "=============================================================="
$PY - "$LOGS" << 'PY'
import glob, os, re, sys

logs = sys.argv[1] if len(sys.argv) > 1 else "out_c/expert_merge/lr_probe_logs"

# The training loop logs lines like:
#   step 10 | train_loss 4.1234 | lr 1.00e-04 | 5404 ms/step
# Field names vary by version, so match the step number and any *loss* value.
pat = re.compile(r"step (\d+) \|(.+?)(?:\||$)")
loss_pat = re.compile(r"loss ([\d.]+)")

print("%-4s %-7s %-9s %-9s %-9s %-4s %s" %
      ("arm", "lr", "first", "last", "max", "n", "verdict"))
print("-" * 66)

results = []
for tag, lr in (("A", "1e-4"), ("B", "3e-4"), ("C", "1e-3")):
    path = os.path.join(logs, "arm-%s.log" % tag)
    pts = []
    if os.path.exists(path):
        for ln in open(path, errors="ignore"):
            m = pat.search(ln)
            if not m:
                continue
            lm = loss_pat.search(m.group(2))
            if lm:
                pts.append((int(m.group(1)), float(lm.group(1))))
    if not pts:
        print("%-4s %-7s  no loss lines found in %s" % (tag, lr, path))
        results.append((tag, lr, None, None, None, 0, "NO DATA"))
        continue
    first, last = pts[0][1], pts[-1][1]
    mx = max(p[1] for p in pts)
    ok = (last <= first) and (mx <= 2.0 * first)
    verdict = "PASS" if ok else "FAIL"
    print("%-4s %-7s %-9.4f %-9.4f %-9.4f %-4d %s" %
          (tag, lr, first, last, mx, len(pts), verdict))
    results.append((tag, lr, first, last, mx, len(pts), verdict))

print("")
passing = [r for r in results if r[6] == "PASS"]
if not passing:
    print("no rate passed the collapse check")
else:
    best = min(passing, key=lambda r: (r[3], float(r[1])))
    print("recommended: lr=%s (arm %s, final loss %.4f)" % (best[1], best[0], best[3]))
PY

echo ""
echo "probe done $(date '+%F %T')"
