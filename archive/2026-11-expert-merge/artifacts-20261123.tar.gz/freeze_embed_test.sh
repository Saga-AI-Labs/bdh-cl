#!/usr/bin/env bash
# Verify that --freeze-embed actually holds embed.weight and lm_head fixed.
#
# A hash that does not change proves nothing on its own -- training could simply
# have done nothing. So this runs the SAME 3 steps twice, once without the flag
# (control: hashes must MOVE) and once with it (treatment: hashes must HOLD).
# Both start from the same parent checkpoint, so the only difference is the flag.
set -uo pipefail
cd /srv/coding/bdh-cl || exit 1

PY=.venv/bin/python
PARENT=out_a/bdh_textmix_k25w1024-zh_last.pt
OUTDIR=out_c/expert_merge/freeze_test
mkdir -p "$OUTDIR"

# 3 steps, weight-decay 0: the F-V9 guard refuses a grown-checkpoint init with
# decay when there is no grow path (it would erode the old segments). At three
# steps decay is irrelevant, and setting it to zero keeps the guard intact rather
# than overriding it with --allow-unfrozen-grown-init.
COMMON="--model bdh --dataset textmix --text-mix expert:data/expert/train.txt --text-mix-mb 10 \
  --n-embd 1024 --n-head 16 --mlp-internal-dim-multiplier 896 \
  --block-size 512 --batch-size 1 --max-iters 3 --warmup-iters 1 \
  --weight-decay 0 --init-from $PARENT --out-dir $OUTDIR"

echo "=== CONTROL: 3 steps, NO --freeze-embed (hashes must move) ==="
$PY -u -m pipeline.run train $COMMON --run-name fe-control 2>&1 | tail -12

echo
echo "=== TREATMENT: same 3 steps, WITH --freeze-embed (hashes must hold) ==="
$PY -u -m pipeline.run train $COMMON --run-name fe-test --freeze-embed 2>&1 | tail -12

echo
echo "=== hash comparison ==="
$PY - << 'PY'
import torch, hashlib, glob, os

def h(t):
    return hashlib.sha256(t.detach().float().numpy().tobytes()).hexdigest()[:16]

parent = torch.load("out_a/bdh_textmix_k25w1024-zh_last.pt",
                    map_location="cpu", weights_only=False, mmap=True)["model_state"]
ref = {k: h(parent[k]) for k in ("embed.weight", "lm_head")}
print("parent reference:")
for k, v in ref.items():
    print("  %-14s %s" % (k, v))

for label, pattern in (("control (no freeze)", "out_c/expert_merge/freeze_test/*fe-control*_last.pt"),
                       ("treatment (--freeze-embed)", "out_c/expert_merge/freeze_test/*fe-test*_last.pt")):
    files = sorted(glob.glob(pattern))
    if not files:
        print("\n%s: NO CHECKPOINT FOUND (%s)" % (label, pattern))
        continue
    ck = torch.load(files[0], map_location="cpu", weights_only=False, mmap=True)
    print("\n%s  [%s]" % (label, os.path.basename(files[0])))
    for k in ("embed.weight", "lm_head"):
        got = h(ck["model_state"][k])
        changed = got != ref[k]
        print("  %-14s %s  %s" % (k, got, "CHANGED" if changed else "UNCHANGED"))
    print("  step:", ck.get("step"), "| best_val:", ck.get("best_val"))
PY
