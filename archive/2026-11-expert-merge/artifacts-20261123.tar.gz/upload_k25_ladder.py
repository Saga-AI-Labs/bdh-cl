#!/usr/bin/env python3
"""Upload the K25/W1024 ladder checkpoints to HuggingFace, one file at a time.

Archive: Saga-AI-Labs/bdh-k25w1024-ladder (public; 971 GB exceeds the 100 GB
private limit). Staged files are hardlinks, so staging costs inodes only.

WHY PER-FILE AND NOT upload_folder: huggingface_hub 2.4.0 no longer exposes
`HfApi.upload_large_folder` (verified: only upload_file, upload_folder,
preupload_lfs_files remain). upload_folder would push 51 files as one commit,
which is unrecoverable if a single LFS chunk fails after hours. upload_file per
file is resumable by construction: a completed file is in the repo and is
skipped by size check on the next attempt.

MEMORY GUARD, twice over. This host has ONE 121 GB pool shared by CPU and GPU,
and B1 training holds ~86 GB of it. On 2026-10-28/29 that mechanism produced
three kernel OOM kills before a training phase reached step 1. Two independent
signals gate each file:

  1. MemAvailable must be >= MIN_AVAIL_GB.
  2. No checkpoint in out_c/expert_merge may have been modified in the last
     QUIET_SECONDS. A B1 checkpoint save writes 33.8 GB (weights + Adam state)
     and takes tens of seconds; starting a 19 GB upload read in that window is
     how the pool tips.

Waiting is a sleep loop, never an abort: a paused upload loses nothing, a killed
training run loses 15 hours.
"""

import glob
import os
import sys
import time

REPO = "Saga-AI-Labs/bdh-k25w1024-ladder"
STAGE = "/srv/coding/bdh-cl/hf_k25w1024_stage"
TOKEN_FILE = "/srv/coding/bdh-cl/out_c/hf_token"
LOG = "/srv/coding/bdh-cl/out_c/expert_merge/upload_k25.log"
CHECKPOINT_DIR = "/srv/coding/bdh-cl/out_c/expert_merge"

MIN_AVAIL_GB = 25.0      # headroom the kernel needs before we add cache pressure
QUIET_SECONDS = 90       # a checkpoint written more recently than this is still hot
POLL_SECONDS = 60
RETRIES = 3


def log(msg):
    line = "%s %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
    print(line, flush=True)
    with open(LOG, "a") as f:
        f.write(line + "\n")


def mem_available_gb():
    with open("/proc/meminfo") as f:
        for line in f:
            if line.startswith("MemAvailable:"):
                return int(line.split()[1]) / 1e6
    return 0.0


def quiet_seconds():
    """Seconds since the most recent checkpoint write in the training dir."""
    now = time.time()
    best = None
    for p in glob.glob(os.path.join(CHECKPOINT_DIR, "*.pt")):
        try:
            age = now - os.path.getmtime(p)
        except OSError:
            continue
        if best is None or age < best:
            best = age
    return float("inf") if best is None else best


def gate(api, done):
    """Block until both conditions allow the next file. Returns the reason."""
    waited = 0
    while True:
        avail = mem_available_gb()
        age = quiet_seconds()
        if avail >= MIN_AVAIL_GB and age >= QUIET_SECONDS:
            if waited:
                log("  gate open after %ds (avail %.1f GB, checkpoint quiet %.0fs)"
                    % (waited, avail, age))
            return
        if waited == 0:
            log("  gate closed: avail %.1f GB (need %.0f), checkpoint age %.0fs (need %d)"
                % (avail, MIN_AVAIL_GB, age if age != float("inf") else -1, QUIET_SECONDS))
        time.sleep(POLL_SECONDS)
        waited += POLL_SECONDS


def remote_state(api):
    """Map path -> size for what is already in the repo."""
    info = api.repo_info(repo_id=REPO, repo_type="dataset", files_metadata=True)
    out = {}
    for s in (info.siblings or []):
        size = getattr(s, "size", None)
        out[s.rfilename] = size if size is not None else -1
    return out


def main():
    if not os.path.exists(TOKEN_FILE):
        sys.exit("missing token file: " + TOKEN_FILE)
    token = open(TOKEN_FILE).read().strip()
    if not token:
        sys.exit("empty token file")

    files = sorted(glob.glob(os.path.join(STAGE, "*.pt")))
    if not files:
        sys.exit("nothing staged in " + STAGE)
    total = sum(os.path.getsize(f) for f in files)
    log("start: %d files, %.2f GB -> %s" % (len(files), total / 1e9, REPO))
    log("gate: avail >= %.0f GB and no checkpoint younger than %ds"
        % (MIN_AVAIL_GB, QUIET_SECONDS))

    from huggingface_hub import HfApi
    api = HfApi(token=token)

    have = remote_state(api)
    log("remote currently holds %d files" % len(have))

    uploaded = skipped = failed = 0
    for i, path in enumerate(files, 1):
        name = os.path.basename(path)
        size = os.path.getsize(path)

        if have.get(name) == size:
            skipped += 1
            log("[%d/%d] skip %s (already present, %d bytes)" % (i, len(files), name, size))
            continue

        gate(api, have)

        for attempt in range(1, RETRIES + 1):
            try:
                log("[%d/%d] upload %s (%.2f GB, attempt %d)"
                    % (i, len(files), name, size / 1e9, attempt))
                api.upload_file(path_or_fileobj=path, path_in_repo=name,
                                repo_id=REPO, repo_type="dataset")
                uploaded += 1
                break
            except Exception as e:
                log("  attempt %d FAILED: %s: %s" % (attempt, type(e).__name__, e))
                if attempt == RETRIES:
                    failed += 1
                    log("  giving up on %s after %d attempts" % (name, RETRIES))
                else:
                    time.sleep(30 * attempt)

    log("upload phase done: %d uploaded, %d skipped, %d failed"
        % (uploaded, skipped, failed))

    # Verification: size match against what the repo reports. Size is the cheap
    # check; the LFS sha256 is compared where the API exposes it.
    log("verifying against the remote")
    final = remote_state(api)
    missing, wrong = [], []
    for path in files:
        name = os.path.basename(path)
        size = os.path.getsize(path)
        if name not in final:
            missing.append(name)
        elif final[name] not in (-1, size):
            wrong.append((name, final[name], size))

    log("verification: %d in repo, %d missing, %d size-mismatch"
        % (len(files) - len(missing) - len(wrong), len(missing), len(wrong)))
    for n in missing[:10]:
        log("  MISSING %s" % n)
    for n, r, l in wrong[:10]:
        log("  SIZE MISMATCH %s: remote %d local %d" % (n, r, l))

    if missing or wrong:
        log("NOT CLEAN - do not delete anything locally")
        return 1
    log("clean. local files may be considered safe to remove after a second opinion.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
