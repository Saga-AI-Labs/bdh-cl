#!/usr/bin/env python3
"""Verify the K25/W1024 ladder archive: local SHA256 vs HuggingFace LFS SHA256.

Why this exists: the upload phase reported "51 uploaded, 0 failed" and the repo shows
971.32 GB, which matches the staging size. That is size agreement, not content
agreement. Before anything local is deleted, the LFS content hashes must match.

HF stores LFS objects by SHA256 and the API exposes them per file. Comparing the two
is the only check that proves the bytes are identical, not merely the same length.

Run: detached; 905 GB of hashing takes 15-30 min on NVMe.
"""
import hashlib
import json
import os
import sys
import time

REPO = "Saga-AI-Labs/bdh-k25w1024-ladder"
STAGE = "/srv/coding/bdh-cl/hf_k25w1024_stage"
TOKEN_FILE = "/srv/coding/bdh-cl/out_c/hf_token"
LOG = "/srv/coding/bdh-cl/out_c/expert_merge/checksum_verify.log"
OUT = "/srv/coding/bdh-cl/out_c/expert_merge/checksum_verify.json"


def log(msg):
    line = "%s %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
    print(line, flush=True)
    with open(LOG, "a") as f:
        f.write(line + "\n")


def sha256_file(path, chunk=8 * 1024 * 1024):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def main():
    from huggingface_hub import HfApi
    api = HfApi(token=open(TOKEN_FILE).read().strip())
    info = api.repo_info(repo_id=REPO, repo_type="dataset", files_metadata=True)

    remote = {}
    for s in (info.siblings or []):
        lfs = getattr(s, "lfs", None) or {}
        sha = lfs.get("sha256") if isinstance(lfs, dict) else None
        remote[s.rfilename] = {"size": getattr(s, "size", None), "sha256": sha}

    log("remote: %d files" % len(remote))
    files = sorted(f for f in remote if f.endswith(".pt"))
    log("checkpoint files to verify: %d" % len(files))

    results = []
    ok = mismatch = missing_local = no_remote_hash = 0
    for i, name in enumerate(files, 1):
        path = os.path.join(STAGE, name)
        r = remote[name]
        if not os.path.exists(path):
            missing_local += 1
            results.append({"file": name, "status": "MISSING_LOCAL"})
            log("[%d/%d] MISSING_LOCAL %s" % (i, len(files), name))
            continue
        if not r["sha256"]:
            no_remote_hash += 1
            results.append({"file": name, "status": "NO_REMOTE_HASH"})
            log("[%d/%d] NO_REMOTE_HASH %s" % (i, len(files), name))
            continue
        local_sha = sha256_file(path)
        match = (local_sha == r["sha256"])
        if match:
            ok += 1
        else:
            mismatch += 1
        results.append({"file": name, "status": "OK" if match else "MISMATCH",
                        "local_sha256": local_sha, "remote_sha256": r["sha256"],
                        "size_local": os.path.getsize(path), "size_remote": r["size"]})
        log("[%d/%d] %s %s" % (i, len(files), "OK" if match else "MISMATCH", name))

    summary = {"files": len(files), "ok": ok, "mismatch": mismatch,
               "missing_local": missing_local, "no_remote_hash": no_remote_hash}
    log("summary: %s" % json.dumps(summary))
    with open(OUT, "w") as f:
        json.dump({"summary": summary, "results": results}, f, indent=2)
    log("wrote %s" % OUT)
    return 0 if (mismatch == 0 and missing_local == 0) else 1


if __name__ == "__main__":
    sys.exit(main())
